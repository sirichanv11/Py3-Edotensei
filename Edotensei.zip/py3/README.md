# NewSatriaPy3

install python3

install pip3

install pip3 rsa , requests , thrift,bs4,gtts,googletrans,linepy

Versi login ada 3 versi.. email.. qr dan token

gunakan bot dengan bijak
